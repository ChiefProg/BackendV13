package io.getarrays.securecapita.issues.cts.ctsict;

public interface CtsictService {
    Ctspens createCtspens(Ctspens ctspens);
}
