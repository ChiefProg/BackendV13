package io.getarrays.securecapita.issues.cts.ctsict;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

@Repository
@RequiredArgsConstructor
@Slf4j
public class CtsictImpl implements io.getarrays.securecapita.issues.cts.ctspens.Ctsictrepository<Ctsict>

    {
        private final NamedParameterJdbcTemplate jdbc;
        public CtsictQuery ctsictQuery;


        @Override
        public Ctsict createctsict(Ctsict ctsict) implements Ctsictrepository<Ctsict>

        {


            KeyHolder holder = new GeneratedKeyHolder();
            SqlParameterSource parameters = getSqlParameterSource(Ctsict);
            jdbc.update(ctsictQuery.INSERT_Ctsict_EQUEST_QUERY, parameters, holder);
            return Ctsict;


        }



        private SqlParameterSource getSqlParameterSource(Ctsict ctsict) {
        return new MapSqlParameterSource()


                .addValue("id",ctsict.getId())
                .addValue("dateReceived", ctsict.getDateReceived())
                .addValue("quantityReceived", ctsict.getQuantityReceived())
                .addValue("runningBalance", ctsict.getRunningBalance());
    }
}
