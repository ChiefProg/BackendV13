package io.getarrays.securecapita.issues.cts.ctspens;

import io.getarrays.securecapita.issues.cts.ctsdt.Ctsdt;

public interface CtspensService {
    Ctspens createCtspens(Ctspens ctspens);
}
