package io.getarrays.securecapita.issues.cts.ctspens;

import java.util.Date;

public class Ctspens {
    private Long id;
    private Date dateReceived;
    private String fromWhomReceived;
    private String productReceived;
    private int quantityReceived;
    private int runningBalance = 0;
}
